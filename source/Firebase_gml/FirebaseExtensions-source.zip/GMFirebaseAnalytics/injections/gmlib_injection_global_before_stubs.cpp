static bool isInitialized = false;
