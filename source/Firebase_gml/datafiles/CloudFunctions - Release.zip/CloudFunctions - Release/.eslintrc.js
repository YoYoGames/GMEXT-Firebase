module.exports = {
  env: {
    es6: true,
    node: true,
  },
  parserOptions: {
    "ecmaVersion": 2018,
  },
  extends: [
    "eslint:recommended",
    "google",
  ],
  rules: {
    "no-restricted-globals": ["error", "name", "length"],
    "prefer-arrow-callback": "error",
	'indent': 'off',
	'quotes': 'off',
	'spaced-comment': 'off',
	'no-tabs': 'off',
	'brace-style': 'off',
	'no-trailing-spaces': 'off',
	'prefer-const': 'off',
	'comma-dangle': 'off',
	'padded-blocks': 'off',
	'key-spacing': 'off',
	'max-len': 'off',
	'eol-last': 'off',
	'no-mixed-spaces-and-tabs': 'off',
	'no-multiple-empty-lines': 'off',
	'comma-spacing': 'off',
	'object-curly-spacing': 'off',
	'no-unused-vars': 'off',
	'keyword-spacing': 'off',
  },
  overrides: [
    {
      files: ["**/*.spec.*"],
      env: {
        mocha: true,
      },
      rules: {},
    },
  ],
  globals: {},
};
