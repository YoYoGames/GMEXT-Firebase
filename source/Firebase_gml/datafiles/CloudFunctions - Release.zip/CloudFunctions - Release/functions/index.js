
'use strict';

const functions = require('firebase-functions');
const admin = require('firebase-admin');

const cors = require('cors')({origin: true});

//https://firebase.google.com/docs/admin/setup
admin.initializeApp({
    credential: admin.credential.applicationDefault(),
    databaseURL: '' // This is your realtime database url.
});

exports.echo = functions.https.onRequest((req, res) => 
{
	cors(req, res, () => 
	{
		res.status(200).send(req.body);
	});
});

//https://stackoverflow.com/questions/42751074/how-to-protect-firebase-cloud-function-http-endpoint-to-allow-only-firebase-auth
exports.tokenDecoder = functions.https.onRequest((req, res) => 
{
	cors(req, res, () => 
	{
		let idToken = req.body.idToken;
		console.log("tokenDecoder2");
		//https://firebase.google.com/docs/auth/admin/verify-id-tokens
		admin.auth().verifyIdToken(idToken).then((decodedToken) =>
		{
			//let uid = decodedToken.uid;//This is useful most of times
			//Do things here, like this: admin.auth().deleteUser(uid);
			
			res.status(200).send(decodedToken);

			return true;
		
		}).catch((error)=>
		{
			res.status(400).send({"message":error});
		});
	});
});


exports.geolocation = functions.https.onRequest(async (req, res) => 
{
	cors(req,res, () => 
	{
		let idToken = req.body.idToken;
		admin.auth().verifyIdToken(idToken).then((decodedToken) => 
		{
			//https://medium.com/mop-developers/free-ip-based-geolocation-with-google-cloud-functions-f92e20d47651
			const data = 
			{
				country: req.headers["x-appengine-country"],
				region: req.headers["x-appengine-region"],
				city: req.headers["x-appengine-city"],
				cityLatLong: req.headers["x-appengine-citylatlong"],
				userIP: req.headers["x-appengine-user-ip"]
			};
			
			res.status(200).send(data);
			return true;
			
		}).catch((error)=>
		{
			console.log(error);
			res.status(400).send({"message":error});
		});
	});
});


// Should active permisions in this links:
//1) Upgrade to Blaze plan
//2) Enable this: https://console.developers.google.com/apis/library/iam.googleapis.com
//3) Add "Service Account Token Creator" next steps and links:
//       https://console.cloud.google.com/iam-admin/iam
//       https://stackoverflow.com/questions/54066947/cant-create-a-custom-token-in-firebase-cloud-functions-because-the-service-acco
// 
// Search for:
// $YOURPROJECTID + @appspot.gserviceaccount.com press 'edit' icon and then 'add'
// on "Service Accounts" and select "Service Account Token Creator"
exports.customSignUp = functions.https.onRequest((req, res) => 
{
	cors(req, res, () => 
	{
		let uid = req.body.uid;//And decode here
		
		//https://firebase.google.com/docs/reference/admin/node/admin.auth.Auth-1#createcustomtoken
		//https://firebase.google.com/docs/auth/admin/create-custom-tokens
		admin.auth().createCustomToken(uid).then((customToken) =>
		{
			res.status(200).send({"customToken":customToken});
			return true;
		})
		.catch((error) =>
		{
			res.status(400).send({"message":error});
			return false;
		});
	});
});

