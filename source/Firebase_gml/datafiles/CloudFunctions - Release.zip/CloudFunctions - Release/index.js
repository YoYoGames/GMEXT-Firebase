
/**
 * Import function triggers from their respective submodules:
 *
 * const {onCall} = require("firebase-functions/v2/https");
 * const {onDocumentWritten} = require("firebase-functions/v2/firestore");
 *
 * See a full list of supported triggers at https://firebase.google.com/docs/functions
 */

const { onRequest } = require("firebase-functions/v2/https");

const { initializeApp, cert } = require("firebase-admin/app");
const { getAuth } = require('firebase-admin/auth');
const { getDatabase } = require('firebase-admin/database');
const { getAppCheck } = require('firebase-admin/app-check');

const functions = require('firebase-functions');

const fs = require('fs');

// INSTALL THIS FOR APPLE SIGN IN ----> npm install jsonwebtoken axios
const jwt = require('jsonwebtoken');
const axios = require('axios');

function readFile(filePath) {
	try {
		const data = fs.readFileSync(filePath);
		return data.toString();
	} catch (error) {
		console.error(`Got an error trying to read the file: ${error.message}`);
	}
}

//https://stackoverflow.com/questions/78547472/how-to-initialize-v2-firebase-cloud-functions-to-authenticate-as-firebase-admin
const app = initializeApp({
	"credential": cert("./yoyoplayservices-13954376-a273bfb40f71.json"),
	"databaseURL":"https://yoyoplayservices-13954376-default-rtdb.firebaseio.com/"
});

// ############ OAUTH ############

function getParamsFromUrl(url) {
    url = decodeURI(url);
    if (typeof url === 'string') {
        let params = url.split('?');
        let eachParamsArr = params[1].split('&');
        let obj = {};
        if (eachParamsArr && eachParamsArr.length) {
            eachParamsArr.map((param) => {
                let keyValuePair = param.split('=');
                let key = keyValuePair[0];
                let value = keyValuePair[1];
                obj[key] = value;
            });
        }
        return obj;
    }
}

const YYGoogleSignInConfig = JSON.parse(readFile("./YYGoogleSignInConfig.json"));

exports.GoogleSignIn = functions.https.onRequest(async (request, response) => {

	const clientId = YYGoogleSignInConfig.clientId;
	const clientSecret = YYGoogleSignInConfig.clientSecret;
	const redirectUri = YYGoogleSignInConfig.redirectUri;

	// Utility function to extract query parameters from URL
	const getDecodedParamsFromUrl = (url) => {
		const urlObj = new URL(url, `https://${process.env.GCLOUD_PROJECT}.cloudfunctions.net`);
		return Object.fromEntries(urlObj.searchParams.entries());
	};

    try {
        // Verify that the request is a GET
        if (request.method !== 'GET') {
            response.status(405).send('Method Not Allowed');
            return;
        }

		// These params will be decoded (important for "code")
        const params = getDecodedParamsFromUrl(request.url);

        // Extract data from the request URL parameters
        const { code, state } = params;
        if (!code || !state) {
            response.status(400).send('Missing required parameters');
            return;
        }

        // Prepare the data for the token request (code is already encoded)
        const tokenData = new URLSearchParams({
            grant_type: 'authorization_code',
            code: code,
            redirect_uri: redirectUri,
            client_id: clientId,
            client_secret: clientSecret,
        });

        // Exchange the authorization code for tokens
        const tokenResponse = await axios.post('https://oauth2.googleapis.com/token', tokenData.toString(), {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });

        const tokens = tokenResponse.data;

        // Store tokens in the Firebase Realtime Database
        await getDatabase().ref('/GoogleSignIn/' + state).set({
            tokens: tokens,
            timestamp: Date.now(),
        });

        // Respond to the request
        response.status(200).send("Authentication successful");
    } catch (error) {
        console.error('Error handling Google sign-in:', error.response ? error.response.data : error.message);
        // Optionally, provide more detailed error information based on `error.response.data`
        response.status(500).send("Internal Server Error");
    }
});

exports.GoogleSignIn_Search = onRequest({cors: true}, async (request, response) => {
	const snapshot = await getDatabase().ref('/GoogleSignIn/' + request.body.state).once('value');
	
	try {
		if(snapshot.exists()) {
			await getDatabase().ref('/GoogleSignIn/' + request.body.state).remove();
			response.send(JSON.stringify(snapshot.val().tokens));
		} else {
			response.send("NO_EXISTS");
		}
	}
	catch(e)
	{
		response.send(e.message);
	}
});

const YYAppleSignInConfig = JSON.parse(readFile("./YYAppleSignInConfig.json"));

exports.AppleSignIn = functions.https.onRequest(async (request, response) => {

	const clientId = YYAppleSignInConfig.clientId;
	const redirectUri = YYAppleSignInConfig.redirectUri;
	const keyId = YYAppleSignInConfig.keyId;
	const teamId = YYAppleSignInConfig.teamId;
	const privateKey = readFile(YYAppleSignInConfig.AuthFilePathP8);

	try {
		// Verify that the request is a POST
		if (request.method !== 'POST') {
			response.status(405).send('Method Not Allowed');
			return;
		}

		// Parse the body
		const contentType = request.headers['content-type'] || '';
		if (!contentType.includes('application/x-www-form-urlencoded')) {
			response.status(400).send('Unsupported Content-Type');
			return;
		}

		// Extract data from the request body
		const { code, state } = request.body;
		if (!code || !state) {
			response.status(400).send('Missing required parameters');
			return;
		}

		// Generate the client_secret
		const claims = {
			iss: teamId,
			iat: Math.floor(Date.now() / 1000),
			exp: Math.floor(Date.now() / 1000) + 15777000, // Valid for up to 6 months
			aud: 'https://appleid.apple.com',
			sub: clientId,
		};
	
		const clientSecret = jwt.sign(claims, privateKey, {
			algorithm: 'ES256',
			header: {
				alg: 'ES256',
				kid: keyId,
			},
		});

		// Exchange the authorization code for tokens
		const tokenResponse = await axios.post('https://appleid.apple.com/auth/token', null, {
			params: {
				grant_type: 'authorization_code',
				code: code,
				redirect_uri: redirectUri,
				client_id: clientId,
				client_secret: clientSecret,
			},
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded',
			},
		});

		const tokens = tokenResponse.data;

		// Store tokens in our database
		await getDatabase().ref('/AppleSignIn/' + state).set({
			tokens: tokens,
			timestamp: Date.now(),
		});


		// Respond to the request
		response.status(200).send('Authentication successful');
	} catch (error) {
		console.error('Error handling Apple sign-in:', error);
		response.status(500).send('Internal Server Error');
	}
});

exports.AppleSignIn_Search = onRequest({cors: true}, async (request, response) => {
	const snapshot = await getDatabase().ref('/AppleSignIn/' + request.body.state).once('value');
	
	try {
		if(snapshot.exists()) {
			const _snapshot_ignored = await getDatabase().ref('/AppleSignIn/' + request.body.state).remove();
			response.send(JSON.stringify(snapshot.val().tokens));
		}
		else {
			response.send("NO_EXISTS");
		}
	}
	catch(e) {
		response.send(e.message);
	}
});

const YYFacebookSignInConfig = JSON.parse(readFile("./YYFacebookSignInConfig.json"));

exports.FacebookSignIn = onRequest({cors: true}, async (request, response) => {

	const clientId = YYFacebookSignInConfig.clientId;
	const clientSecret = YYFacebookSignInConfig.clientSecret;
	const redirectUri = YYFacebookSignInConfig.redirectUri;

	try {
		// Verify that the request is a GET
        if (request.method !== 'GET') {
            response.status(405).send('Method Not Allowed');
            return;
        }

		// These params will be decoded (important for "code")
        const params = getParamsFromUrl(request.url);

        // Extract data from the request URL parameters
        const { code, state } = params;
        if (!code || !state) {
            response.status(400).send('Missing required parameters');
            return;
        }

		// Exchange the authorization code for tokens	
		const tokenResponse = await axios.get("https://graph.facebook.com/v21.0/oauth/access_token", {
			params: {
				code: code,
				redirect_uri: redirectUri,
				client_secret: clientSecret,
				client_id: clientId
			},
		});

		const tokens = tokenResponse.data;

		// Store tokens in our database
		await getDatabase().ref('/FacebookSignIn/' + state).set({
			tokens: tokens,
			timestamp: Date.now(),
		});
		
		// Respond to the request
		response.status(200).send("Authentication successful");
	} catch (error) {
		console.error('Error handling Facebook sign-in:', error.response ? error.response.data : error.message);
		// Optionally, provide more detailed error information based on `error.response.data`
		response.status(500).send("Internal Server Error");
	}
});
	
exports.FacebookSignIn_Search = onRequest({cors: true}, async (request, response) => {
	const snapshot = await getDatabase().ref('/FacebookSignIn/'+request.body.state).once('value');
	
	try
	{
		if(snapshot.exists())
		{
			const _snapshot_ignored = await getDatabase().ref('/FacebookSignIn/'+request.body.state).remove();
			response.send(JSON.stringify(snapshot.val().tokens));
		}
		else {
			response.send("NO_EXISTS");
		}
	}
	catch(e)
	{
		response.send(e.message);
	}
});

// ######## FIREBASE DEMO ########

exports.helloWorld = onRequest({cors: true}, async (request, response) => {
	console.log("Hello logs!", {structuredData: true});
	response.send("Hello from Firebase!");
});

exports.echo = onRequest({cors: true}, (request, response) => {
	console.log("Hello logs!", {structuredData: true});
	response.send(request.body);
});
	
exports.tokenDecoder = onRequest({cors: true}, (request, response) => {
	console.log("Hello logs!", {structuredData: true});

	let idToken = request.body.idToken;
	
	// response.send(idToken);
	// return true;
		
	console.log("tokenDecoder2");
	//https://firebase.google.com/docs/auth/admin/verify-id-tokens
	getAuth().verifyIdToken(idToken).then((decodedToken) =>
	{
		//let uid = decodedToken.uid;//This is useful most of times
		//Do things here, like this: admin.auth().deleteUser(uid);
		
		response.send(decodedToken);

		return true;
	
	}).catch((error)=>
	{
		response.send({"message":error});
	});
});

// Should active permisions in this links:
//1) Upgrade to Blaze plan
//2) Enable this: https://console.developers.google.com/apis/library/iam.googleapis.com
//3) Add "Service Account Token Creator" next steps and links:
//       https://console.cloud.google.com/iam-admin/iam
//       https://stackoverflow.com/questions/54066947/cant-create-a-custom-token-in-firebase-cloud-functions-because-the-service-acco
// 
// Search for:
// $YOURPROJECTID + @appspot.gserviceaccount.com press 'edit' icon and then 'add'
// on "Service Accounts" and select "Service Account Token Creator"
exports.customSignUp = onRequest({cors: true}, (request, response) => {
	let uid = request.body.uid;//And decode here
	
	//https://firebase.google.com/docs/reference/admin/node/admin.auth.Auth-1#createcustomtoken
	//https://firebase.google.com/docs/auth/admin/create-custom-tokens

	getAuth().createCustomToken(uid).then((customToken) =>
	{
		// res.status(200).send({"customToken":customToken});
		response.send({"customToken":customToken});
		return true;
	}).catch((error) =>
	{
		response.send({"message":error});
		return false;
	});
});
	
exports.appCheckToken = onRequest({cors: true}, (request, response) => {
	const token = request.body.token;
	
	try
	{
		getAppCheck().verifyToken(token).then((decodedToken) =>
		{
			response.send("Valid Token!");
			return true;
		
		}).catch((error)=>
		{
			response.send("Unauthorized Token!");
		});
	}
	catch(e)
	{
		response.send(e);
	}
});

///////////////////////Unable of upgrade from gen1 to gen2 :( 

// exports.geolocation = functions.https.onRequest(async (req, res) => 
// {
	// cors(req,res, () => 
	// {
		// let idToken = req.body.idToken;
		// admin.auth().verifyIdToken(idToken).then((decodedToken) => 
		// {
			// //https://medium.com/mop-developers/free-ip-based-geolocation-with-google-cloud-functions-f92e20d47651
			// const data = 
			// {
				// country: req.headers["x-appengine-country"],
				// region: req.headers["x-appengine-region"],
				// city: req.headers["x-appengine-city"],
				// cityLatLong: req.headers["x-appengine-citylatlong"],
				// userIP: req.headers["x-appengine-user-ip"]
			// };
			
			// res.status(200).send(data);
			// return true;
			
		// }).catch((error)=>
		// {
			// console.log(error);
			// res.status(400).send({"message":error});
		// });
	// });
// });
