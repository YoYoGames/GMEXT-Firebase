
/**
 * Import function triggers from their respective submodules:
 *
 * const {onCall} = require("firebase-functions/v2/https");
 * const {onDocumentWritten} = require("firebase-functions/v2/firestore");
 *
 * See a full list of supported triggers at https://firebase.google.com/docs/functions
 */

const {onRequest} = require("firebase-functions/v2/https");
const logger = require("firebase-functions/logger");

const {initializeApp, cert} = require("firebase-admin/app");
const {getAuth} = require('firebase-admin/auth');
const {getDatabase} = require('firebase-admin/database');
const {getMessaging} = require('firebase-admin/messaging');
const {log, warn} = require('firebase-functions/logger');
const {onValueWritten} = require('firebase-functions/v2/database');
const { getAppCheck } = require('firebase-admin/app-check');

const functions = require('firebase-functions');

const fs = require('fs');
//INSTALL THIS FOR APPLE SIGN IN ----> npm install jsonwebtoken axios
const jwt = require('jsonwebtoken');
const axios = require('axios');

//https://stackoverflow.com/questions/78547472/how-to-initialize-v2-firebase-cloud-functions-to-authenticate-as-firebase-admin
const app = initializeApp({
							credential: cert("./yoyoplayservices-13954376-a273bfb40f71.json"),
							"databaseURL":"https://yoyoplayservices-13954376-default-rtdb.firebaseio.com/"
						});



function getParamsFromUrl(url) {
    url = decodeURI(url);
    if (typeof url === 'string') {
        let params = url.split('?');
        let eachParamsArr = params[1].split('&');
        let obj = {};
        if (eachParamsArr && eachParamsArr.length) {
            eachParamsArr.map(param => {
                let keyValuePair = param.split('=')
                let key = keyValuePair[0];
                let value = keyValuePair[1];
                obj[key] = value;
            })
        }
        return obj;
    }
}

// exports.GoogleSignIn = onRequest({cors: true},async (request, response) => {
		// var _obj = getParamsFromUrl(request.url);
		// const snapshot = await getDatabase().ref('/GoogleSignIn/'+_obj.state).set({code:_obj.code,timestamp:Date.now()});
		// response.send("OK" + request.url);
	// });

const YYGoogleSignInConfig = JSON.parse(readFile("./YYGoogleSignInConfig.json"));
const GoogleSignIn_ClientId = YYGoogleSignInConfig.clientId;
const GoogleSignIn_ClientSecret = YYGoogleSignInConfig.clientSecret;
const GoogleSignIn_RedirectUri = YYGoogleSignInConfig.redirectUri;

exports.GoogleSignIn = onRequest({cors: true},async (request, response) => {
	
		var _obj = getParamsFromUrl(request.url);
		const oauthRequest = {
				url: (new URL("https://oauth2.googleapis.com/token")).toString(),
				params: {
					client_id: encodeURIComponent("20722703459-2lblr1ppet3454b102121vn0s8gkqls2.apps.googleusercontent.com"),
					client_secret: encodeURIComponent("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"),
					code: _obj.code,
					grant_type: "authorization_code",
					redirect_uri: encodeURIComponent("https://googlesignin-tclduhxwfq-uc.a.run.app")///"https%3A%2F%2Fgooglesignin-tclduhxwfq-uc.a.run.app",
				},
			};
			
		try{
		
		const oauthResponse = await axios.post(oauthRequest.url,oauthRequest.params,{headers: {'Content-Type': 'application/x-www-form-urlencoded'}});
		const tokens = oauthResponse.data;
		
		// Store tokens in our database
		const snapshot = await getDatabase().ref('/GoogleSignIn/' + _obj.state).set({
				tokens: tokens,
				timestamp: Date.now(),
			});
		
		response.send("OK");

		}
		catch(e)
		{
			response.send(e.message + "\n\n" + JSON.stringify(oauthRequest));
		}
	});

exports.GoogleSignIn_Search = onRequest({cors: true},async (request, response) => {
		const snapshot = await getDatabase().ref('/GoogleSignIn/'+request.body.state).once('value');
		
		try
		{
		if(snapshot.exists())
		{
			const _snapshot_ignored = await getDatabase().ref('/GoogleSignIn/'+request.body.state).remove();
			response.send(snapshot.val().code);
		}
		else
			response.send("NO_EXISTS");
		}
		catch(e)
		{
			response.send(e.message);
		}
	});

function readFile(filePath) {
  try {
    const data = fs.readFileSync(filePath);
    return data.toString();
  } catch (error) {
    console.error(`Got an error trying to read the file: ${error.message}`);
  }
}

const YYAppleSignInConfig = JSON.parse(readFile("./YYAppleSignInConfig.json"));
const AppleSignIn_KeyId = YYAppleSignInConfig.keyId;
const AppleSignIn_TeamId = YYAppleSignInConfig.teamId;
const AppleSignIn_ClientId = YYAppleSignInConfig.clientId;
const AppleSignIn_RedirectUri = YYAppleSignInConfig.redirectUri;
const AppleSignIn_PrivateKey = readFile(YYAppleSignInConfig.AuthFilePathP8);

exports.AppleSignIn = functions.https.onRequest(async (request, response) => {
	try {
		// Verify that the request is a POST
		if (request.method !== 'POST') {
			response.status(405).send('Method Not Allowed');
			return;
		}

		// Parse the body
		const contentType = request.headers['content-type'] || '';
		if (!contentType.includes('application/x-www-form-urlencoded')) {
			response.status(400).send('Unsupported Content-Type');
			return;
		}

		// Extract data from the request body
		const { code, state } = request.body;
		if (!code || !state) {
			response.status(400).send('Missing required parameters');
			return;
		}

		// Generate the client_secret
		const clientSecret = generateClientSecret();

		// Exchange the authorization code for tokens
		const tokenResponse = await axios.post('https://appleid.apple.com/auth/token', null, {
			params: {
				grant_type: 'authorization_code',
				code: code,
				redirect_uri: AppleSignIn_RedirectUri, // this is this function
				client_id: AppleSignIn_ClientId,
				client_secret: clientSecret,
			},
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded',
			},
		});

		const tokens = tokenResponse.data;

		// Store tokens in our database
		const snapshot = await getDatabase().ref('/AppleSignIn/' + state).set({
				tokens: tokens,
				timestamp: Date.now(),
			});


		// Respond to the request
		response.status(200).send('Authentication successful');
	} catch (error) {
		console.error('Error handling Apple sign-in:', error);
		response.status(500).send('Internal Server Error');
	}
});

// Function to generate the client_secret JWT
function generateClientSecret() {

	const headers = {
		alg: 'ES256',
		kid: AppleSignIn_KeyId,
	};

	const claims = {
		iss: AppleSignIn_TeamId,
		iat: Math.floor(Date.now() / 1000),
		exp: Math.floor(Date.now() / 1000) + 15777000, // Valid for up to 6 months
		aud: 'https://appleid.apple.com',
		sub: AppleSignIn_ClientId,
	};

	const clientSecret = jwt.sign(claims, AppleSignIn_PrivateKey, {
		algorithm: 'ES256',
		header: headers,
	});

	return clientSecret;
}

exports.AppleSignIn_Search = onRequest({cors: true},async(request, response) => {
		const snapshot = await getDatabase().ref('/AppleSignIn/'+request.body.state).once('value');
		
		try
		{
			if(snapshot.exists())
			{
				const _snapshot_ignored = await getDatabase().ref('/AppleSignIn/'+request.body.state).remove();
				response.send(JSON.stringify(snapshot.val().tokens));
			}
			else
				response.send("NO_EXISTS");
		}
		catch(e)
		{
			response.send(e.message);
		}
	});

const YYFacebookSignInConfig = JSON.parse(readFile("./YYFacebookSignInConfig.json"));
const FacebookSignIn_ClientId = YYFacebookSignInConfig.clientId;
const FacebookSignIn_ClientSecret = YYFacebookSignInConfig.clientSecret;
const FacebookSignIn_RedirectUri = YYFacebookSignInConfig.redirectUri;

exports.FacebookSignIn = onRequest({cors: true},async(request, response) => {
		var _obj = getParamsFromUrl(request.url);
		
		// Exchange the authorization code for tokens
		const params = "?code=" + _obj.code +
                    "&redirect_uri=" + FacebookSignIn_RedirectUri +
					"&client_secret=" + FacebookSignIn_ClientSecret + 
                    "&client_id=" + FacebookSignIn_ClientId;
		
		const tokenResponse = await axios.get('https://graph.facebook.com/v21.0/oauth/access_token' + params, null);

		const tokens = tokenResponse.data;

		// Store tokens in our database
		const snapshot = await getDatabase().ref('/FacebookSignIn/' + _obj.state).set({
				tokens: tokens,
				timestamp: Date.now(),
			});
		
		response.send("OK: " + JSON.stringify(tokens));
	});
	
exports.FacebookSignIn_Search = onRequest({cors: true},async(request, response) => {
		const snapshot = await getDatabase().ref('/FacebookSignIn/'+request.body.state).once('value');
		
		try
		{
			if(snapshot.exists())
			{
				const _snapshot_ignored = await getDatabase().ref('/FacebookSignIn/'+request.body.state).remove();
				response.send(JSON.stringify(snapshot.val().tokens));
			}
			else
				response.send("NO_EXISTS");
		}
		catch(e)
		{
			response.send(e.message);
		}
	});



exports.helloWorld = onRequest({cors: true},async(request, response) => {
	  console.log("Hello logs!", {structuredData: true});
	  response.send("Hello from Firebase!");
	});

exports.echo = onRequest({cors: true},(request, response) => {
	  console.log("Hello logs!", {structuredData: true});
	  response.send(request.body);
	});
	

exports.tokenDecoder = onRequest({cors: true},(request, response) => {
	  console.log("Hello logs!", {structuredData: true});
	
		let idToken = request.body.idToken;
		
		// response.send(idToken);
		// return true;
			
		console.log("tokenDecoder2");
		//https://firebase.google.com/docs/auth/admin/verify-id-tokens
		getAuth().verifyIdToken(idToken).then((decodedToken) =>
		{
			//let uid = decodedToken.uid;//This is useful most of times
			//Do things here, like this: admin.auth().deleteUser(uid);
			
			response.send(decodedToken);

			return true;
		
		}).catch((error)=>
		{
			response.send({"message":error});
		});
	});

// Should active permisions in this links:
//1) Upgrade to Blaze plan
//2) Enable this: https://console.developers.google.com/apis/library/iam.googleapis.com
//3) Add "Service Account Token Creator" next steps and links:
//       https://console.cloud.google.com/iam-admin/iam
//       https://stackoverflow.com/questions/54066947/cant-create-a-custom-token-in-firebase-cloud-functions-because-the-service-acco
// 
// Search for:
// $YOURPROJECTID + @appspot.gserviceaccount.com press 'edit' icon and then 'add'
// on "Service Accounts" and select "Service Account Token Creator"
exports.customSignUp = onRequest({cors: true},(request, response) => {
	  logger.info("Hello logs!", {structuredData: true});
	
		let uid = request.body.uid;//And decode here
		
		//https://firebase.google.com/docs/reference/admin/node/admin.auth.Auth-1#createcustomtoken
		//https://firebase.google.com/docs/auth/admin/create-custom-tokens

		getAuth().createCustomToken(uid).then((customToken) =>
		{
			// res.status(200).send({"customToken":customToken});
			response.send({"customToken":customToken});
			return true;
		}).catch((error) =>
		{
			response.send({"message":error});
			return false;
		});
		
	});
	
exports.appCheckToken = onRequest({cors: true},(request, response) => {
	  logger.info("Hello logs!", {structuredData: true});
		
		const token = request.body.token;
		
		try
		{
			getAppCheck().verifyToken(token).then((decodedToken) =>
			{
				response.send("Valid Token!");
				return true;
			
			}).catch((error)=>
			{
				response.send("Unauthorized Token!");
			});
		}
		catch(e)
		{
			response.send(e);
		}
	});



///////////////////////Unable of upgrade from gen1 to gen2 :( 

// exports.geolocation = functions.https.onRequest(async (req, res) => 
// {
	// cors(req,res, () => 
	// {
		// let idToken = req.body.idToken;
		// admin.auth().verifyIdToken(idToken).then((decodedToken) => 
		// {
			// //https://medium.com/mop-developers/free-ip-based-geolocation-with-google-cloud-functions-f92e20d47651
			// const data = 
			// {
				// country: req.headers["x-appengine-country"],
				// region: req.headers["x-appengine-region"],
				// city: req.headers["x-appengine-city"],
				// cityLatLong: req.headers["x-appengine-citylatlong"],
				// userIP: req.headers["x-appengine-user-ip"]
			// };
			
			// res.status(200).send(data);
			// return true;
			
		// }).catch((error)=>
		// {
			// console.log(error);
			// res.status(400).send({"message":error});
		// });
	// });
// });
