
/**
 * Import function triggers from their respective submodules:
 *
 * const {onCall} = require("firebase-functions/v2/https");
 * const {onDocumentWritten} = require("firebase-functions/v2/firestore");
 *
 * See a full list of supported triggers at https://firebase.google.com/docs/functions
 */

const {onRequest} = require("firebase-functions/v2/https");
const logger = require("firebase-functions/logger");

const {initializeApp, cert} = require("firebase-admin/app");
const {getAuth} = require('firebase-admin/auth');
const {getDatabase} = require('firebase-admin/database');
const {getMessaging} = require('firebase-admin/messaging');
const {log, warn} = require('firebase-functions/logger');
const {onValueWritten} = require('firebase-functions/v2/database');
const { getAppCheck } = require('firebase-admin/app-check');

//https://stackoverflow.com/questions/78547472/how-to-initialize-v2-firebase-cloud-functions-to-authenticate-as-firebase-admin
const app = initializeApp({
							credential: cert("./yoyoplayservices-13954376-044bb4a677c8.json"),
						});


exports.helloWorld = onRequest({cors: true},(request, response) => {
	  logger.info("Hello logs!", {structuredData: true});
	  response.send("Hello from Firebase!");
	});

exports.echo = onRequest({cors: true},(request, response) => {
	  logger.info("Hello logs!", {structuredData: true});
	  response.send(request.body);
	});
	

exports.tokenDecoder = onRequest({cors: true},(request, response) => {
	  logger.info("Hello logs!", {structuredData: true});
	
		let idToken = request.body.idToken;
		
		// response.send(idToken);
		// return true;
			
		console.log("tokenDecoder2");
		//https://firebase.google.com/docs/auth/admin/verify-id-tokens
		getAuth().verifyIdToken(idToken).then((decodedToken) =>
		{
			//let uid = decodedToken.uid;//This is useful most of times
			//Do things here, like this: admin.auth().deleteUser(uid);
			
			response.send(decodedToken);

			return true;
		
		}).catch((error)=>
		{
			response.send({"message":error});
		});
	});

// Should active permisions in this links:
//1) Upgrade to Blaze plan
//2) Enable this: https://console.developers.google.com/apis/library/iam.googleapis.com
//3) Add "Service Account Token Creator" next steps and links:
//       https://console.cloud.google.com/iam-admin/iam
//       https://stackoverflow.com/questions/54066947/cant-create-a-custom-token-in-firebase-cloud-functions-because-the-service-acco
// 
// Search for:
// $YOURPROJECTID + @appspot.gserviceaccount.com press 'edit' icon and then 'add'
// on "Service Accounts" and select "Service Account Token Creator"
exports.customSignUp = onRequest({cors: true},(request, response) => {
	  logger.info("Hello logs!", {structuredData: true});
	
		let uid = request.body.uid;//And decode here
		
		//https://firebase.google.com/docs/reference/admin/node/admin.auth.Auth-1#createcustomtoken
		//https://firebase.google.com/docs/auth/admin/create-custom-tokens

		getAuth().createCustomToken(uid).then((customToken) =>
		{
			// res.status(200).send({"customToken":customToken});
			response.send({"customToken":customToken});
			return true;
		}).catch((error) =>
		{
			response.send({"message":error});
			return false;
		});
		
	});
	
exports.appCheckToken = onRequest({cors: true},(request, response) => {
	  logger.info("Hello logs!", {structuredData: true});
		
		const token = request.body.token;
		
		try
		{
			getAppCheck().verifyToken(token).then((decodedToken) =>
			{
				response.send("Valid Token!");
				return true;
			
			}).catch((error)=>
			{
				response.send("Unauthorized Token!");
			});
		}
		catch(e)
		{
			response.send(e);
		}
	});



///////////////////////Unable of upgrade from gen1 to gen2 :( 

// exports.geolocation = functions.https.onRequest(async (req, res) => 
// {
	// cors(req,res, () => 
	// {
		// let idToken = req.body.idToken;
		// admin.auth().verifyIdToken(idToken).then((decodedToken) => 
		// {
			// //https://medium.com/mop-developers/free-ip-based-geolocation-with-google-cloud-functions-f92e20d47651
			// const data = 
			// {
				// country: req.headers["x-appengine-country"],
				// region: req.headers["x-appengine-region"],
				// city: req.headers["x-appengine-city"],
				// cityLatLong: req.headers["x-appengine-citylatlong"],
				// userIP: req.headers["x-appengine-user-ip"]
			// };
			
			// res.status(200).send(data);
			// return true;
			
		// }).catch((error)=>
		// {
			// console.log(error);
			// res.status(400).send({"message":error});
		// });
	// });
// });
